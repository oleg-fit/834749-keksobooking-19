'use strict';

(function () {
  var mapFilter = document.querySelector('.map__filters');
  var mapFilterSelects = mapFilter.querySelectorAll('select');
  var mapFilterFieldset = mapFilter.querySelectorAll('fieldset');
  var mapFilterSelectType = mapFilter.querySelector('#housing-type');
  var mapFilterSelectPrice = mapFilter.querySelector('#housing-price');
  var mapFilterSelectRooms = mapFilter.querySelector('#housing-rooms');
  var mapFilterSelectGuests = mapFilter.querySelector('#housing-guests');
  var mapFilterFeaturesList = mapFilter.querySelector('#housing-features');

  var PriceTypeMap = {
    LOW: 'low',
    MIDDLE: 'middle',
    HIGH: 'high'
  };

  var PriceValueMap = {
    MIN: 10000,
    MAX: 50000
  };

  var activateFilterForm = function () {
    window.form.removeAttributeFormElements(mapFilterSelects);
    window.form.removeAttributeFormElements(mapFilterFieldset);
  };

  var deactivateFilterForm = function () {
    window.form.addAttributeFormElements(mapFilterSelects);
    window.form.addAttributeFormElements(mapFilterFieldset);
  };

  var сhangeFilterFormState = function (state) {
    if (state) {
      activateFilterForm();
    } else {
      deactivateFilterForm();
    }
  };

  var filterTheForm = function () {

    var copyData = window.data.serverAdvertisment.slice();

    var filterHousingType = function (element) {
      return mapFilterSelectType.value === 'any' ? true : element.offer.type === mapFilterSelectType.value;
    };

    var filterHousingPrice = function (element) {
      switch (mapFilterSelectPrice.value) {
        case PriceTypeMap.LOW:
          return element.offer.price < PriceValueMap.MIN;
        case PriceTypeMap.MIDDLE:
          return element.offer.price >= PriceValueMap.MIN && element.offer.price <= PriceValueMap.MAX;
        case PriceTypeMap.HIGH:
          return element.offer.price > PriceValueMap.MAX;
        default:
          return true;
      }
    };

    var filterHousingRooms = function (element) {
      return mapFilterSelectRooms.value === 'any' ? true : parseInt(mapFilterSelectRooms.value, 10) === element.offer.rooms;
    };

    var filterHousingGuests = function (element) {
      return mapFilterSelectGuests.value === 'any' ? true : parseInt(mapFilterSelectGuests.value, 10) === element.offer.guests;
    };

    var filterHousingFeatures = function (element) {
      var filterResult = true;

      for (var i = 0; i < mapFilterFeaturesList.length; i++) {

        if (mapFilterFeaturesList[i].checked) {

          if (element.offer.features.indexOf(mapFilterFeaturesList[i].value) === -1) {

            filterResult = false;
            break;
          }
        }
      }
      return filterResult;
    };

    copyData = copyData.filter(filterHousingType);

    copyData = copyData.filter(filterHousingPrice);

    copyData = copyData.filter(filterHousingRooms);

    copyData = copyData.filter(filterHousingGuests);

    copyData = copyData.filter(filterHousingFeatures);

    window.pin.removePins();

    window.filter.dataSort = copyData;

    window.pin.createMapElements();
  };


  window.filter = {
    сhangeFilterFormState: сhangeFilterFormState,
    filterTheForm: filterTheForm,
    mapFilter: mapFilter
  };

})();
